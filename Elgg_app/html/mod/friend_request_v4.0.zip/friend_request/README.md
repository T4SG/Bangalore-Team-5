Friend request
==============
Let users confirm friend requests. Make all friend requests reciprocal.

Features
-----------

- Add friends like on Facebook / LinkedIn, so you have to approve a request

Credits
----------
The original idea for this plugin was made by Bosssumon and Zac Hopkinson

To Do
--------

- custom message on request
- admin options for menu options
- notification to requester on accept
- move menu items to hooks