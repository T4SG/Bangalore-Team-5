<?php ?>
.elgg-river-layout .elgg-form-thewire-add .elgg-input-access {
	float: none;
}

.thewire-tools-widget-access {
	max-width: 200px;
}