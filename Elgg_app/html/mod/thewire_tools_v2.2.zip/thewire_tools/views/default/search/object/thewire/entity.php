<?php 

	echo elgg_view("object/thewire", $vars);