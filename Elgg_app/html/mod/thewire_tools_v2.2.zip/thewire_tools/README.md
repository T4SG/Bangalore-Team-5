The Wire Tools
==============

Extend the functionality of The Wire

Features
--------

- Wire posts in groups (optional)
- Notification on mention (user tool setting, default off)
- Mentions
- Autocomplete of friends and (recently used) hashtags when composing a wire post
- Search wire posts
- Delete action returns to referer page
- Index widget (for use with Widget Manager plugin)
- Group widget (for use with Widget Manager plugin)
- Post to the wire widget (index / dashboard) (no entity listing)
- Optional Extend thewire widgets with a post form

ToDo
----

- url shortning
- post thewire on 'enter' in message
- share on the wire
- Ajax pagination (more button)
- move autocomplete to an action
