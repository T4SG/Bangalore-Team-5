Vrawa Theme for Elgg 1.8
UDP SW Social Web
GPL Theme


A clean, super minimal responsive template geared towards professional or educational networks. 
Includes a landing page, and a complete rework of the elgg views.
