<?php

$english = array(
    'menu:site:header:default' => 'Navigation',
    'menu:site:header:more' => 'More',
);

add_translation("en", $english);